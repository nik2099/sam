const ProfileImageCircle = ({ initials, size }) => {
  return (

    <div className="avatar-icon-wrapper avatar-icon-wrapper-50 text-center">{initials}</div>

  );
};

export default ProfileImageCircle;
