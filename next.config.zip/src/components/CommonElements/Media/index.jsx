import React from 'react';
import { Media } from 'reactstrap';

const Image = (props) =>(
  <Media {...props.attrImage}/>
);

export default Image;