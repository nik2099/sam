export const CampaignTitle = 'Kampagnen';
export const MyAppTitle = 'Meine Apps';
export const MyDiviceTitle = 'Meine Geräte';
export const PlayerTitle = 'Player';